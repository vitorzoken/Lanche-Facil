package com.example.lanchefacil;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResumoPedidoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo_pedido);

        TextView textViewResumo = findViewById(R.id.textViewResumo);
        Button btnVoltarInicio = findViewById(R.id.btnVoltarInicio);

        Intent intent = getIntent();
        String nome = intent.getStringExtra("NOME_CLIENTE");
        String lanche = intent.getStringExtra("LANCHE_ESCOLHIDO");

        String resumo = "Olá, " + nome + "!\nSeu pedido: " + lanche + "\nfoi registrado com sucesso!";
        textViewResumo.setText(resumo);

        btnVoltarInicio.setOnClickListener(v -> {
            Intent mainIntent = new Intent(ResumoPedidoActivity.this, MainActivity.class);
            mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(mainIntent);
        });
    }
}