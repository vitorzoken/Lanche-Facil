package com.example.lanchefacil;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;

public class FormularioPedidoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_pedido);

        EditText editTextNome = findViewById(R.id.editTextNome);
        RadioGroup radioGroupLanches = findViewById(R.id.radioGroupLanches);
        Button btnConfirmarPedido = findViewById(R.id.btnConfirmarPedido);

        btnConfirmarPedido.setOnClickListener(v -> {
            String nome = editTextNome.getText().toString().trim();
            int selectedId = radioGroupLanches.getCheckedRadioButtonId();

            if (nome.isEmpty()) {
                editTextNome.setError("Digite seu nome");
                return;
            }

            if (selectedId == -1) {
                // Nenhum lanche selecionado
                return;
            }

            RadioButton radioButton = findViewById(selectedId);
            String lanche = radioButton.getText().toString();

            Intent intent = new Intent(FormularioPedidoActivity.this, ResumoPedidoActivity.class);
            intent.putExtra("NOME_CLIENTE", nome);
            intent.putExtra("LANCHE_ESCOLHIDO", lanche);
            startActivity(intent);
        });
    }
}
